Action()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("vk.com", 
		"URL=https://vk.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t229.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("01_login");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"https://vk.com");

	web_submit_data("login.vk.com", 
		"Action=https://login.vk.com/?act=login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/", 
		"Snapshot=t230.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=act", "Value=login", ENDITEM, 
		"Name=role", "Value=al_frame", ENDITEM, 
		"Name=expire", "Value=", ENDITEM, 
		"Name=recaptcha", "Value=", ENDITEM, 
		"Name=captcha_sid", "Value=", ENDITEM, 
		"Name=captcha_key", "Value=", ENDITEM, 
		"Name=_origin", "Value=https://vk.com", ENDITEM, 
		"Name=ip_h", "Value=8518eb9e04199d4c97", ENDITEM, 
		"Name=lg_h", "Value=46c6ae797c38f8a69b", ENDITEM, 
		"Name=email", "Value=inna67rus@gmail.com", ENDITEM, 
		"Name=pass", "Value=966OI&(a", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("notifier.php", 
		"URL=https://vk.com/notifier.php?act=storage_frame&from=vk.com&4", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/", 
		"Snapshot=t231.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://vk.com");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/", 
		"Snapshot=t232.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_get_comms_key", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("q_frame.php", 
		"URL=https://queuev4.vk.com/q_frame.php?7", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/", 
		"Snapshot=t233.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://vk.com");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_2", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/", 
		"Snapshot=t234.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_get_fast_chat", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=cache_time", "Value=0", ENDITEM, 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("vk.com_2", 
		"URL=https://vk.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/", 
		"Snapshot=t235.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_3", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/", 
		"Snapshot=t236.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_stickers_list", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=cache_time", "Value=0", ENDITEM, 
		"Name=need_keywords", "Value=1", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_submit_data("notifier.php_2", 
		"Action=https://vk.com/notifier.php?act=a_reset", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/", 
		"Snapshot=t237.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=al", "Value=1", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://vk.com");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_feed.php", 
		"Action=https://vk.com/al_feed.php?queue", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/feed", 
		"Snapshot=t238.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_get_key", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=need_ignore", "Value=1", ENDITEM, 
		"Name=only_update", "Value=0", ENDITEM, 
		"Name=section", "Value=news", ENDITEM, 
		"Name=subsection", "Value=top", ENDITEM, 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("notifier.php_3", 
		"URL=https://vk.com/notifier.php?act=storage_frame&from=vk.com&4", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/feed", 
		"Snapshot=t239.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_login",LR_AUTO);

	web_url("q_frame.php_2", 
		"URL=https://queuev4.vk.com/q_frame.php?7", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/feed", 
		"Snapshot=t240.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"https://vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_4", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/feed", 
		"Snapshot=t241.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_get_fast_chat", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=cache_time", "Value=1511950610", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_submit_data("im200", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t242.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_release", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022453_846925008_332327367_637231764", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_2", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t243.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022453_846925008_332327367_637231764", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_3", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t244.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022454_846925009_332327368_637231765", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_4", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t245.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022455_846925010_332327369_637231766", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_submit_data("im200_5", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t246.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022456_846925011_332327370_637231767", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_start_transaction("02_go_to_messages");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("im200_6", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t247.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022457_846925012_332327371_637231768", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("al_im.php_5", 
		"URL=https://vk.com/al_im.php?__query=im&_full_page=true&_ref=left_nav&al=-1&al_id=44752200&_rndVer=22933", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/feed", 
		"Snapshot=t248.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://queuev4.vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("im200_7", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t249.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022458_846925013_332327372_637231769", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_submit_data("al_im.php_6", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t250.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=get_emoji_list", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_7", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t251.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_dialogs_preload", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=rs", "Value=", ENDITEM, 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("upload_doc.php", 
		"Action=https://pu.vk.com/c816633/upload_doc.php", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/im", 
		"Snapshot=t252.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=mid", "Value=44752200", ENDITEM, 
		"Name=aid", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=41f3b8047e493c509c02c956f306de04", ENDITEM, 
		"Name=rhash", "Value=fbac79c682ccf0009298ba634508d9e8", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=act", "Value=check_upload", ENDITEM, 
		"Name=type", "Value=doc", ENDITEM, 
		"Name=ondone", "Value=Upload.callbacks.oncheck0", ENDITEM, 
		LAST);

	web_submit_data("upload.php", 
		"Action=https://pu.vk.com/c834200/upload.php", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/im", 
		"Snapshot=t253.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=mid", "Value=44752200", ENDITEM, 
		"Name=aid", "Value=-3", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=49955628736e5cbc1e4e8b48015a39ee", ENDITEM, 
		"Name=rhash", "Value=8d7fa173d2e59faf208273712113d46c", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=act", "Value=check_upload", ENDITEM, 
		"Name=type", "Value=photo", ENDITEM, 
		"Name=ondone", "Value=Upload.callbacks.oncheck1", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("im200_8", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t254.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022459_846925014_332327373_637231770", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_submit_data("upload_fails.php", 
		"Action=https://vk.com/upload_fails.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t255.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=success", ENDITEM, 
		"Name=aid", "Value=-3", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=error", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=61d3e0d7726cdc054d8e43290e8c307e", ENDITEM, 
		"Name=mid", "Value=44752200", ENDITEM, 
		"Name=server", "Value=834200", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("upload_fails.php_2", 
		"Action=https://vk.com/upload_fails.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t256.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=success", ENDITEM, 
		"Name=aid", "Value=1", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=error", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=085dbed7ef34d0c05eb23ed0bb4d3e0a", ENDITEM, 
		"Name=mid", "Value=44752200", ENDITEM, 
		"Name=server", "Value=816633", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_submit_data("im200_9", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t257.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022460_846925015_332327374_637231771", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_10", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t258.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022461_846925016_332327375_637231772", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_end_transaction("02_go_to_messages",LR_AUTO);

	web_submit_data("im200_11", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t259.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022462_846925017_332327376_637231773", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_12", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t260.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022463_846925018_332327377_637231774", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_13", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t261.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022464_846925019_332327378_637231775", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_14", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t262.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022465_846925020_332327379_637231776", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_15", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t263.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022466_846925021_332327380_637231777", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_submit_data("im200_16", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t264.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022467_846925022_332327381_637231778", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_17", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t265.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022468_846925023_332327382_637231779", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_18", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t266.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022469_846925024_332327383_637231780", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_19", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t267.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022470_846925025_332327384_637231781", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_20", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t268.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022471_846925026_332327385_637231782", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_start_transaction("03_search_whom");

	web_submit_data("im200_21", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t269.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022472_846925027_332327386_637231783", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_submit_data("im200_22", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t270.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022473_846925028_332327387_637231784", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_submit_data("al_search.php", 
		"Action=https://vk.com/al_search.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t271.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=get_top_friends", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		LAST);

	web_submit_data("al_im.php_8", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t272.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_hints", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=peerIds", "Value=", ENDITEM, 
		"Name=query", "Value=false", ENDITEM, 
		"Name=str", "Value=false", ENDITEM, 
		LAST);

	web_submit_data("al_search.php_2", 
		"Action=https://vk.com/al_search.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im", 
		"Snapshot=t273.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=get_pages", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_submit_data("im200_23", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t274.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6W8IH1KnxYWvWkRoy3TC3Hhi_9geJ1bU9SA0CmYI_8gXWVzn7OVw6XQAbE7KUe2d2plvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022474_846925029_332327388_637231785", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_submit_data("al_im.php_9", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?q=byyf", 
		"Snapshot=t275.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_hints", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=peerIds", "Value=44752200", ENDITEM, 
		"Name=query", "Value=all", ENDITEM, 
		"Name=str", "Value=byyf", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_revert_auto_header("Origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_10", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?q=byyf", 
		"Snapshot=t276.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_search", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=from", "Value=all", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=e20851715c65c4c392", ENDITEM, 
		"Name=offset", "Value=0", ENDITEM, 
		"Name=q", "Value=byyf", ENDITEM, 
		LAST);

	lr_end_transaction("03_search_whom",LR_AUTO);

	lr_start_transaction("04_write");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_submit_data("al_im.php_11", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t277.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_start", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=block", "Value=true", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=history", "Value=true", ENDITEM, 
		"Name=msgid", "Value=false", ENDITEM, 
		"Name=peer", "Value=44752200", ENDITEM, 
		"Name=prevpeer", "Value=0", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("al_im.php_12", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t278.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_typing", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=hash", "Value=1511950685_3c3469a6777d848b08", ENDITEM, 
		"Name=peer", "Value=44752200", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_submit_data("al_im.php_13", 
		"Action=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t279.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_send", ENDITEM, 
		"Name=al", "Value=1", ENDITEM, 
		"Name=gid", "Value=0", ENDITEM, 
		"Name=guid", "Value=1511950692271100", ENDITEM, 
		"Name=hash", "Value=1511950685_3c3469a6777d848b08", ENDITEM, 
		"Name=media", "Value=", ENDITEM, 
		"Name=msg", "Value=test_qwerfghjkl", ENDITEM, 
		"Name=random_id", "Value=1553297194", ENDITEM, 
		"Name=to", "Value=44752200", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("im200_24", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t280.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6WlvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022475_332327389_637231786", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Origin", 
		"https://vk.com");

	web_custom_request("al_im.php_14", 
		"URL=https://vk.com/al_im.php", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t281.inf", 
		"Mode=HTML", 
		"Body=act=a_mark_read&al=1&gid=0&hash=1511950685_3c3469a6777d848b08&ids[0]=233413&peer=44752200", 
		LAST);

	web_add_auto_header("Origin", 
		"https://queuev4.vk.com");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("im200_25", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t282.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6WlvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022476_332327390_637231787", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_end_transaction("04_write",LR_AUTO);

	web_revert_auto_header("X-Requested-With");

	web_submit_data("im200_26", 
		"Action=https://queuev4.vk.com/im200", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/javascript", 
		"Referer=https://queuev4.vk.com/q_frame.php?7", 
		"Snapshot=t283.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=act", "Value=a_check", ENDITEM, 
		"Name=id", "Value=44752200", ENDITEM, 
		"Name=key", "Value=inZhozAbRLbxcBJYXipwm8zCEz3VyePlzlaC6TKuYNPdUVyZqnkpgMjNxVWpRa6WlvfQBhZcYN9sR6OywS9uic_8nXgq59l5DIygkJZNU1Ccd_NFQz0qt3fOS1VbpZ4aO9HJD2CajdXmECb6y9dt1Ocuyr0EcQ43S9gzAykv9ubg_5afKfSH0mxHjJhlNFgJ", ENDITEM, 
		"Name=ts", "Value=1634022477_332327391_637231788", ENDITEM, 
		"Name=wait", "Value=25", ENDITEM, 
		LAST);

	lr_start_transaction("05_logout");

	web_revert_auto_header("Origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login.vk.com_2", 
		"URL=https://login.vk.com/?act=logout&hash=911588a3651b8c28d3&reason=tn&_origin=https://vk.com", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t284.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://vk.com");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("errors.php", 
		"URL=https://vk.com/errors.php", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vk.com/im?sel=44752200", 
		"Snapshot=t285.inf", 
		"Mode=HTML", 
		"Body=host=vk.com&id=44752200&lang=0&loc=im%3Fsel%3D44752200&module=im&msg=&realloc=https%3A%2F%2Fvk.com%2Fim%3Fsel%3D44752200&stack=ReferenceError%3A%20Invalid%20left-hand%20side%20in%20assignment%0A%20%20%20%20at%20topError%20(https%3A%2F%2Fvk.com%2Fjs%2Fal%2Fcommon.js%3F1160_3170971789%3A231%3A10)%0A%20%20%20%20at%20https%3A%2F%2Fvk.com%2Fjs%2Fcmodules%2Fweb%2Fimn.js%3F126482867599%3A10%3A13773%0A%20%20%20%20at%20%3Canonymous%3E", 
		LAST);

	lr_end_transaction("05_logout",LR_AUTO);

	return 0;
}
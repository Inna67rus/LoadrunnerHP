#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files

//--------------------------------------------------------------------
// Global Variables

#endif // _GLOBALS_H
